MySQL
===


PostgreSQL
===

-Ddatabase_driverClassName=org.postgresql.Driver
-Ddatabase_url=jdbc:postgresql://host:5432/db
-Ddatabase_username=username
-Ddatabase_password=password

Oracle
===

-Ddatabase_driverClassName=oracle.jdbc.OracleDriver
-Ddatabase_url=jdbc:oracle:thin:@//host:1521/XE
-Ddatabase_username=system
-Ddatabase_password=oracle

`docker run -d -P wnameless/oracle-xe-11g`

Download Oracle JDBC driver from

`docker cp cid:/u01/app/oracle/product/11.2.0/xe/jdbc/lib/ojdbc6.jar /tmp/`

`mvn install:install-file -DgroupId=com.oracle -DartifactId=ojdbc6 -Dversion=11.2.0.2 -Dpackaging=jar -Dfile=/tmp/ojdbc6.jar -DgeneratePom=true`

If you got `ORA-01882: timezone region not found` please add
`-e TZ=UTC` to the docker run command which you use for an app server (Tomcat).