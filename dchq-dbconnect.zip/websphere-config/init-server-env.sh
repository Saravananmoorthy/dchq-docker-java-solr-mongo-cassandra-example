#!/bin/bash

echo database_driverClassName=$database_driverClassName >> /opt/ibm/wlp/usr/servers/defaultServer/server.env
echo database_url=$database_url >> /opt/ibm/wlp/usr/servers/defaultServer/server.env
echo database_username=$database_username >> /opt/ibm/wlp/usr/servers/defaultServer/server.env
echo database_password=$database_password >> /opt/ibm/wlp/usr/servers/defaultServer/server.env
echo solr_host=$solr_host >> /opt/ibm/wlp/usr/servers/defaultServer/server.env
echo solr_port=$solr_port >> /opt/ibm/wlp/usr/servers/defaultServer/server.env
echo mongo_url=$mongo_url >> /opt/ibm/wlp/usr/servers/defaultServer/server.env
echo cassandra_url=$cassandra_url >> /opt/ibm/wlp/usr/servers/defaultServer/server.env
